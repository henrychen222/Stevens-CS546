const userData = require('./userData');

module.exports = {
    userData: userData
};