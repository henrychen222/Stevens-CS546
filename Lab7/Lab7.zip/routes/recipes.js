const express = require('express');
const router = express.Router();
const data = require('../data');
const recipeData = data.recipes;


// router.get('/', (req, res) => {
//     recipeData.getAllRecipes().then((recipeList) => {
//         let recipeString = [];
//         recipeList.forEach((recipe) => {
//             let recipeTemp = {
//                 _id: recipe._id,
//                 title: recipe.title
//             }
//            recipeString.push(recipeTemp);
//         });
//         res.send(recipeString);
//     }, () => {
//         res.status(500).json({error: "Could not contact server"});
//     })
// });

router.get("/", async (req, res) => {
    try {
      const recipeList = await recipeData.getAllRecipes();
      res.json(recipeList);
    } catch (e) {
        res.status(500).json({error: "Could not contact server"});
    }
  });

// router.get('/:id', (req, res) => {
//     recipeData.getRecipeById(req.params.id).then((recipe) => {
//         res.json(recipe);
//     }, () => {
//         res.status(404).json({error: "Recipe not found!"});
//     });
// });


router.get("/:id", async (req, res) => {
    try {
      const recipe = await recipeData.getRecipeById(req.params.id);
      res.json(recipe);
    } catch (e) {
      res.status(404).json({ error: "Recipe not found" });
    }
  });

// router.post('/', (req, res) => {
//     let recipeInfo = req.body;
//     if(!recipeInfo) {
//         res.status(400).json({error: "You must provide info to create a recipe"});
//         return;
//     }
//     if(!recipeInfo.title) {
//         res.status(400).json({error: "You must provide a recipe title"});
//         return;
//     }
//     if(!recipeInfo.ingredients) {
//         res.status(400).json({error: "You must provide ingredients!"});
//         return;
//     }
//     if(!recipeInfo.steps) {
//         res.status(400).json({error: "You must provide steps for your recipe!"});
//         return;
//     }

//     recipeData.addRecipe(
//         recipeInfo.title,
//         recipeInfo.ingredients,
//         recipeInfo.steps,
//         recipeInfo.comments)
//         .then((newRecipe)=> {
//                 res.json(newRecipe);
//                 }, () => {
//                     res.status(500).json({error: "Could not add recipe."});
//                 });
// });


router.post("/", async (req, res) => {
    const recipeInfo = req.body;
    if(!recipeInfo) {
        res.status(400).json({error: "You must provide info to create a recipe"});
        return;
    }
    if(!recipeInfo.title) {
        res.status(400).json({error: "You must provide a recipe title"});
        return;
    }
    if(!recipeInfo.ingredients) {
        res.status(400).json({error: "You must provide ingredients!"});
        return;
    }
    if(!recipeInfo.steps) {
        res.status(400).json({error: "You must provide steps for your recipe!"});
        return;
    }
    try {
      const { title, ingredients, steps} = recipeInfo;
      const newRecipe = await recipeData.addRecipe(title, ingredients, steps);
      res.json(newRecipe);
    } catch (e) {
      res.status(500).json({ error: e });
    }
  });


// router.put('/:id', (req, res)=> {
//     let recipeInfo = req.body;

//     if(!recipeInfo) {
//         res.status(400).json({error: "You must provide info to create a recipe"});
//         return;
//     }

//     let getRecipe = recipeData.getRecipeById(req.params.id).then((recip) =>{
//         return recipeData.updateRecipe(req.params.id, recipeInfo)
//             .then((updatedRecipe) => {
//                 res.json(updatedRecipe)
//             }, () => {
//                 res.status(500).json({error: "Could not updated recipe"});
//             });
//     }).catch((err) => {
//         res.status(404).json({error: err});
//     });
// });

router.put("/:id", async (req, res) => {
    const recipeInfo = req.body;

    if(!recipeInfo) {
        res.status(400).json({error: "You must provide info to create a recipe"});
        return;
    }

    try {
      await recipeData.getRecipeById(req.params.id);
    } catch (e) {
      res.status(404).json({ error: "Post not found" });
    }
  
    try {
      const updatedRecipe = await recipeData.updatedRecipe(req.params.id, recipeInfo);
      res.json(updatedRecipe);
    } catch (e) {
      res.status(500).json({ error: e });
    }
  });

// router.delete('/:id', (req,res) => {
//     let recipe = recipeData.getRecipeById(req.params.id).then(() => {
//         return recipeData.removeRecipe(req.params.id)
//             .then(() => {
//                 res.status(200).json("Recipe removed");
//             }).catch(() => {
//                 res.status(500).json("Could not contact server");
//             });
//     }).catch(()=> {
//         res.status(404).json({error: "Could not find recipe!"});
//     });
// });

router.delete("/:id", async (req, res) => {
    try {
      await recipeData.getRecipeById(req.params.id);
    } catch (e) {
      res.status(404).json({ error: "Recipe not found" });
    }
    try {
      await recipeData.removeRecipe(req.params.id);
    } catch (e) {
      res.status(500).json({ error: e });
    }
  });




module.exports = router