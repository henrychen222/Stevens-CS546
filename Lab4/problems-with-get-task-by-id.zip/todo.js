const mongoCollections = require("./mongoCollections");
const todo = mongoCollections.todo;
const uuidv4 = require('uuid/v4');


module.exports = {

    async createTask(title, description) {
        if (!title) throw "You must provide a title for your task";

        // if (!description || !Array.isArray(description))
        //     throw "You must provide an array of description";

        if (description.length === 0) throw "You must provide at least one description.";
        const taskCollection = await todo();

        let newTask = {
            new_id: uuidv4(),   //randomly generate an id 
            title: title,
            description: description,
            completed: false,
            completedAt: null
        };

        const created_task_info = await taskCollection.insertOne(newTask);
        if (created_task_info.insertedCount === 0) throw "Could not add task";

        const random_v4_id = created_task_info.insertedId;
        //get the task by searching with the new id
        const task = await this.getTask(random_v4_id);
        return task;
    },

    async getAllTasks() {

        const taskCollection = await todo();

        const all_tasks = await taskCollection.find({}).toArray();

        return all_tasks;
    },


    async getTask(id) {
                
        if (!id) throw "You must provide an id to search for";

        const taskCollection = await todo();
        const task = await taskCollection.findOne({ _id: id });
        if (task === null) throw "No task with that id";

        return task;
    },

    //modify or update task in database
    async completeTask(taskId) {
        if (!taskId) throw "You must provide an id to search for";
       
                    
        const taskCollection = await todo();
        const comepletedTask = {
            //modify two items            
            completed: true,
            completedAt: Date.now()
        };
    
        const updateInfo = await taskCollection.updateOne({ _id: id }, comepletedTask);
        if (updatedInfo.modifiedCount === 0) {
          throw "could not update task successfully";
        }
    
        return await this.getTask(id);
    },

    async removeTask(id) {

        if (!id) throw "You must provide an id to search for";

        const taskCollection = await todo();
        const deleted_task_info = await taskCollection.removeOne({ _id: id });

        if (deleted_task_info.deletedCount === 0) {
            throw `Could not delete task with id of ${id}`;
        }
        0;
    }

}