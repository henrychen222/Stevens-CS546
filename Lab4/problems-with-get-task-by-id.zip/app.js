const todoItems = require("./todo");
const connection = require("./mongoConnection");


async function main() {
    //1.create Ponder Dinosaurs Task
    const ponder_task = await todoItems.createTask("Ponder Dinosaurs", "Has Anyone Really Been Far Even as Decided to Use Even Go Want to do Look More Like?");
    console.log("-----------Ponder Dinosaurs Task created----------------------------------" + "\n");
    console.log(ponder_task);
    console.log("\n")

    //2.create Pokemon task
    const pokemon_task = await todoItems.createTask("Play Pokemon with Twitch TV", "Should we revive Helix?");
    console.log("-----------Pokemon Task created-------------------------------------------" + "\n");
    console.log(pokemon_task);
    console.log("\n")

    //3.query all the two tasks
    const getAllTasks = await todoItems.getAllTasks();
    console.log("-----------All Tasks are here----------------------------------------------" + "\n");
    console.log(getAllTasks);

    //4.After all the tasks are logged, remove the first task
    const removeTask = await todoItems.removeTask(ponder_task._id);  //problem

    try {
        return await todoItems.getTask("9714a17c-f228-49e9-a772-9086f5ff8bfb");
    } catch (error) {
      console.error(error);
   }
    
    console.log("-----------Ponder Dinosaurs Task has already been removed------------------" + "\n");


    //5.Query all the remaining tasks and log them
    const get_all_remaining_task = await todoItems.getAllTasks();
    console.log("-----------All the remaining tasks are here------------------" + "\n");

    //6.Complete the remaining task/Modify the task
    const task = await todoItems.getTask(pokemon_task._id);   //problem
    const finishedTask = await todoItems.completeTask(task._id); 
    console.log("-----------Completed tasks are here------------------" + "\n");
    console.log(finishedTask);
   

   }

    



    

    // //complete task
    // //const complete_task = await todoItems.getTask("9714a17c-f228-49e9-a772-9086f5ff8bfb");
    // //const finishedTask = await todoItems.completeTask(complete_task._id); 
    // const finishedTask = await todoItems.complete_task(
    //     createdTask._id,
    //     ["a descriptive bio of the task"],
    //     createdTask.body,
    //     post.poster.id
    //   );

    // console.log("complete task:" + "\n");
    // console.log(finishedTask);

    

    


main()