const mongoCollections = require('../config/mongoCollections');
const recipes = mongoCollections.recipes;
const uuid = require('node-uuid');

let exportedMethods = {
    async getAllRecipes() {

        const recipeCollection = await recipes();
        return await recipeCollection.find({}).toArray();

        // return recipes().then((recipeCollection) => {
        //     return recipeCollection.find({}).toArray();
        // })
    },
    async getRecipeById(id) {

        const recipeCollection = await recipes();
        const recipe = await recipeCollection.findOne({ _id: id });

        if (!recipe) throw "No recipe found";
        return recipe;

        // return recipes().then((recipeCollection) => {
        //     return recipeCollection.findOne({ _id: id }).then((recipe) => {
        //         if (!recipe) {
        //             throw ("No recipe found");
        //         }
        //         return recipe;
        //     });
        // });
    },

    async addRecipe(title, ingredients, steps) {
        if (typeof title !== "string") throw "No title provided";
        
        //make ingredients to be an array if it's not an array
        if (!Array.isArray(ingredients)) {
            ingredients = [];
        }

        if (!Array.isArray(steps)) {
            steps = [];
        }

        const recipeCollection = await recipes();

        const newRecipe = {
            _id: uuid.v4(),
            title: title,
            ingredients: ingredients,
            steps: steps
        };

        const new_inserted_recipe = await recipeCollection.insertOne(newRecipe);
        const newId = new_inserted_recipe.insertedId;
        return await this.getRecipeById(newId);

        // return recipes().then((recipeCollection) => {
        //     let newRecipe = {
        //         _id: uuid.v4(),
        //         title: title,
        //         ingredients: ingredients,
        //         steps: steps,
        //         comments: []
        //     };
        //     return recipeCollection.insertOne(newRecipe).then((newInsert) => {
        //         return newInsert.insertedId;
        //     }).then((newId) => {
        //         return this.getRecipeById(newId);
        //     });
        // });
    },
    async removeRecipe(id) {
        const recipeCollection = await recipes();
        const deletionInfo = await recipeCollection.removeOne({ _id: id });
        if (deletionInfo.deletedCount === 0) {
            throw `Could not delete recipe with id of ${id}`;
        }

        // return recipes().then((recipeCollection) => {
        //     return recipeCollection.removeOne({ _id: id }).then((deletedInfo) => {
        //         if (deletedInfo.deletedCount === 0) {
        //             return Promise.reject(`Could not delete recipe with id ${id}`);
        //         }
        //     });
        // });
    },
    async updateRecipe(id, updatedRecipe) {
        const recipeCollection = await recipes();

        const updatedRecipeData = {};

        if (updatedRecipe.title) {
            updatedRecipeData.title = updatedRecipe.title;
        }

        if (updatedRecipe.ingredients) {
            updatedRecipeData.ingredients = updatedRecipe.ingredients;
        }

        if (updatedRecipe.steps) {
            updatedRecipeData.steps = updatedRecipe.steps;
        }

        if (updatedRecipe.comments) {
            updatedRecipeData.comments.push(updatedRecipe.comments);
        }

        let updateCommand = {
            $set: updatedRecipeData
        };
        const query = {
            _id: id
        };
        await recipeCollection.updateOne(query, updateCommand);

        return await this.getRecipeById(id);

        // return recipes().then((recipeCollection) => {
        //     let updatedRecipeData = {}

        //     if (updatedRecipe.title) {
        //         updatedRecipeData.title = updatedRecipe.title;
        //     }

        //     if (updatedRecipe.ingredients) {
        //         updatedRecipeData.ingredients = updatedRecipe.ingredients;
        //     }

        //     if (updatedRecipe.steps) {
        //         updatedRecipeData.steps = updatedRecipe.steps;
        //     }

        //     if (updatedRecipe.comments) {
        //         updatedRecipeData.comments.push(updatedRecipe.comments);
        //     }

        //     let updateCommand = {
        //         $set: updatedRecipeData
        //     };

        //     return recipeCollection.updateOne({ _id: id }, updateCommand).then(() => {
        //         return this.getRecipeById(id);
        //     });
        // });
    }
}

module.exports = exportedMethods;