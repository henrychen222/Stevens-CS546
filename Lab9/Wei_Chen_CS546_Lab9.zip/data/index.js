const palindrome = require('./palindrome');

module.exports = {
    palindrome: palindrome
};
